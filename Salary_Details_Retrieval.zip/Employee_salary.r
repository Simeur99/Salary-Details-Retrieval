#load necessary libraries
library(readr)

#assign variable to the zip.file
zip_file <- "Employee Profile.zip"

#unzip the file
unzip(zip_file, exdir = "Employee_profile")

#find and read the csv
csv_file <- list.files("Employee_profile",
                       pattern = "\\.csv$", full.names = TRUE)[1]

# Read the csv
employee_data <- readr::read_csv(csv_file)

# Display the data
print(employee_data)
